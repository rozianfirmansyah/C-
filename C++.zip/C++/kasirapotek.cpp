#include <iostream>
#include <string.h>
#include <stdlib.h>
int data,nilai[5];
char poli[5][20];
using namespace std;
void kasir()
{
	int bpjs,bayar,kembali,rm;
	int jumlah=0;
	cout<<"NO RM\t: ";cin>>rm;
	for(int a=0;a<data;a++)
	{
		cout<<"\nNO POLI/UNIT\t: "<<a+1<<endl;
		cout<<"POLI/UNIT\t: "<<poli[a]<<endl;
		cout<<"BIAYA(Rp)\t: "<<nilai[a]<<endl;
		jumlah=jumlah+nilai[a];
	}
	cout<<"\nJumlah\t\t: "<<jumlah<<endl;
	cout<<"BPJS(1)/UMUM(2)\t: ";cin>>bpjs;
	if(bpjs==1)
	{
		cout<<"BAYAR\t: Rp.0"<<endl;
		cout<<"KEMBALI\t: Rp.0"<<endl;
	}
	else
	{
		cout<<"BAYAR\t\t: ";cin>>bayar;
		kembali=bayar-jumlah;
		cout<<"KEMBALI\t\t: "<<kembali<<endl;
	}
}
int main ()
{
	char username[15],password[15],huruf;
	int pilih;
	do
	{
		cout<<"USERNAME: ";cin>>username;
		cout<<"PASSWORD: ";cin>>password;
		system ("cls");
		if (strcmp(username,"rozian_f")==0&& strcmp(password,"1234")==0)
		cout<<"\nLOGIN BERHASIL"<<endl;
		else
		cout<<"\nLOGIN SALAH!!!"<<endl;
	}
	while (!strcmp(username,"rozian_f")==0 || !strcmp(password,"1234")==0);
	do
	{
		cout<<"\nMENU:"<<endl;
		cout<<"1. INPUT DATA MASTER"<<endl;
		cout<<"2. KASIR"<<endl;
		cout<<"3. EXIT"<<endl;
		cout<<"Masukkan Pilihan: ";cin>>pilih;
		switch (pilih)
		{
			case 1:
			cout<<"\nINPUT DATA MASTER"<<endl;
			cout<<"Jumlah Data= ";cin>>data;
			for(int a=0;a<data;a++)
			{
				cout<<"\nNO POLI/UNIT KE-"<<a+1<<endl;
				cout<<"POLI/UNIT\t: ";cin>>poli[a];
				cout<<"NILAI(Rp)\t: ";cin>>nilai[a];
			}
			break;
			case 2:
			cout<<"Kasir"<<endl;
			kasir();
			break;
			case 3:
			exit(0);
			break;
			default:
			cout<<"error 404 not found"<<endl;
		}
		cout<<"kembali ke menu(y/n)= ";cin>>huruf;
		system("cls");
	}
	while(huruf=='y');
}
