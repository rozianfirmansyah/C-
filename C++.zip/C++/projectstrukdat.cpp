#include <iostream>
#include <malloc.h>
#define True 1
#define False 0
using namespace std;
typedef int typeinfo;
typedef struct typequeue *typeptr;
struct typequeue
{
	typeinfo info;
	typeptr next;
};
typedef struct{
	int no;
	char nama[50], poli[50];
}antrian;
typeptr qdepan, qbelakang;
void buatqueue();
int queuekosong();
void enqueue(typeinfo IB);
void dequeue();
void cetakqueue();
int x;
antrian pasien[30];
int main()
{ 
	buatqueue();
	int pilih;
	char huruf;
	do
	{
		cout<<"Menu"<<endl;
		cout<<"1. Input Antrian"<<endl;
		cout<<"2. Lihat Antrian"<<endl;
		cout<<"3. Panggil Antrian"<<endl;
		cout<<"4. Lihat Data Terpanggil"<<endl;
		cout<<"pilih: ";cin>>pilih;
		switch (pilih)
		{
			case 1:
			char lagi;
			do
			{
				cout<<"masukkan antrian: ";cin>>x;
				enqueue(x);
				cout<<"masukkan antrian lagi?(y/n) ";cin>>lagi;
			}while(lagi=='y');
			break;
			case 2:
			cetakqueue();
			break;
			case 3:
			dequeue();
			break;
			case 4:
			break;
		}cout<<"Kembali ke menu?(y/n) ";cin>>huruf;
	}while (huruf=='y');
	
}
void buatqueue()
{ qdepan=(typequeue *) malloc(sizeof(typequeue));
  qdepan=NULL;
  qbelakang=qdepan;
}
int queuekosong()
{ if(qdepan==NULL)
	 return(True);
  else
	 return(False);
}
void enqueue(typeinfo IB)
{ typeptr NB;
  NB=(typequeue *) malloc(sizeof(typequeue));
  NB->info=IB;
  if (qdepan==NULL)
	  qdepan=NB;
  else
	  qbelakang->next=NB;
  qbelakang=NB;
  qbelakang->next=NULL;
}
void dequeue()
{
  typeptr hapus;
  if (queuekosong())
  { 
     cout << "Queue masih kosong !";
  }
  else
  { hapus=qdepan;
	 qdepan=hapus->next;
	 
 }
}

void cetakqueue()
{
  typeptr bantu;
  bantu=qdepan;
  do { cout << " " << bantu->info;
		 cout << " ";
		 bantu=bantu->next;
  } while(bantu!=NULL);
  cout<<endl;
}
