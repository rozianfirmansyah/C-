#include<iostream>
#include<string.h>
#include<iomanip>
using namespace std;

int UBAHDETIK (float tahun);
int MAXTAHUN (float tahun);
void HITUNG(int x);


// Deklarasi menjadi variabel global agar dapat digunakan di seluruh main program dan subprogram
unsigned long long int jumlah = 307357670;
// kolom 1 = untuk menyimpan inisialisasi awal yg akan digunakan dalam rumus
// kolom 2 = untuk menghitung perubahan penduduk selama waktu
float usia20[2] = {(15/100) * jumlah ,  0};
float usia20_50[2] = {(45/100) * jumlah ,  0};
float usia50[2] = {(40/100) * jumlah ,  0};
int Ntahun;

int main(){
	unsigned int waktu;
	
	float persen_tumbuh, komposisi20, komposisi20_50, komposisi50;
	
	cout << "Masukkan tahun yang akan di prediksi (selisih max = 100 tahun) : ";
	cin >> waktu;
	waktu = MAXTAHUN (waktu);
	cout << waktu << endl;
	//waktu = UBAHDETIK (waktu);
	
	int tempTahun = waktu;
	
	waktu = waktu * 365 * 24 * 60 * 60;
	cout << waktu; 
	HITUNG(waktu);
	
	persen_tumbuh = (usia20[1] + usia20_50[1] - usia50[1])*100/jumlah;
	
	jumlah = jumlah /*(usia20[0]*/ + usia20[1] + /*(usia20_50[0] +*/ usia20_50[1] /*+ (usia50[0] */- usia50[1];
	// masih terjadi eror di bagian variabel komposisi berikut
	komposisi20 	= (usia20[0] + usia20[1])/(jumlah) * 100;
	komposisi20_50 	= (usia20_50[0] + usia20_50[1])/(jumlah) * 100;
	komposisi50 	= (usia50[0] - usia50[1])/(jumlah) * 100;
	
	cout << endl
		<< "Jumlah penduduk dalam " << tempTahun << " tahun yang akan datang adalah " << jumlah << endl
		<< setprecision (2)
		<< "Prosentase pertumbuhan penduduk selama " << tempTahun << " tahun adalah " << persen_tumbuh << " %\n"
		<< "Komposisi penduduk pada tahun " << Ntahun << " adalah sbb :\n"
		<< setw(10) << komposisi20 << " % usia <20 tahun\n"
		<< setw(10) << komposisi20_50 << " % usia 20-50 tahun\n"
		<< setw(10) << komposisi50 << " % usia >50 tahun";
	
}

int UBAHDETIK (float tahun){
	int detik;
	tahun =  tahun * 365 * 24 * 60 * 60;
	return tahun;
}

int MAXTAHUN (float x){
	cout << endl;
	Ntahun = x;
	x -= 2017;
	if (0 <= x && x <= 100) return x;
	cout << "Waktu prediksi yang Anda masukkan tidak memenuhi syarat\n"
		<< "Silakan masukkan ulang tahun prediksi : ";
	cin >> x;
	return MAXTAHUN (x);
}

void HITUNG(int x){
	for (int i=1; i<x; i++){
		if (i % 7 == 0) usia20[1]++ ;
		if (i % 35 == 0) usia20_50[1]++ ;
		if (i % 13 == 0) usia50[1]++ ;
	}
}
