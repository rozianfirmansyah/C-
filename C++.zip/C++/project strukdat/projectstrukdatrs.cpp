#include <iostream>
#include <malloc.h>
#include <string.h>
#include <fstream>
#define max 50
#define true 1
#define false 0
using namespace std;
struct typequeue{int belakang;};
typedef struct{
	char alamat[100], penyakit[50];
	int tanggal;
}data;

typedef struct{
	int no;
	char nama[50];
	data datap;
}antrian;
struct typequeue queue;
struct typequeue queue2;
void buatqueue();
void buatqueue2();
void cetakqueue();
void cetakqueue2();
void enqueue();
void enqueue2();
void dequeue();
void carinama();
void carino();
int queuekosong();
int queuepenuh();
int x=0, jumantri=0, y=0, z=0, jumpasien=0;
antrian pasien[30], pasien2[30], temp;
char jawab, jawab1;
FILE *file;
int main()
{	
	int menu;
	buatqueue();
	buatqueue2();
	do
	{
		cout<<"===============\n"<<"==Menu Utama==\n"<<"===============\n";
		cout<<"1. Tambah Antrian\n"<<"2. Lihat Antrian\n"<<"3. Panggil Antrian\n"<<"4. Cari Pasien\n";
		cout<<"Pilih menu : ";cin>>menu;
		switch(menu)
		{
			case 1:
			{
				cout<<"==============TAMBAH ANTRIAN==============\n";
				enqueue();
				cout<<"Kembali ke menu awal?(y/n)";cin>>jawab;
				cout<<endl;
			}
			break;
			case 2:
			{
				cout<<"==============LIHAT ANTRIAN==============\n";
				cetakqueue();
				cout<<"Kembali ke menu awal ?(y/n)";cin>>jawab;
				cout<<endl;
			}
			break;
			case 3:
			{
				cout<<"==============PANGGIL ANTRIAN==============\n";
				cout<<endl<<"Antrian terambil 1"<<endl;
				enqueue2();
				dequeue();
				cout<<"Kembali ke menu awal ?(y/n)";cin>>jawab;
				cout<<endl;
			}
			break;
			case 4:
			{
				cout<<"==============CARI PASIEN==============\n";
				int menuc;
				char jawabc;
				do
				{
					cout<<"1. Berdasar Nama\n"<<"2. Berdasar No Antri\n"<<"3. Tampil Semua\n";
					cout<<"Pilih Menu : ";cin>>menuc;
					switch(menuc)
					{
						case 1:
						{
							carinama();
							cout<<"Kembali ke menu cari ?(y/n)";cin>>jawabc;
						}
						break;
						case 2:
						{
							carino();
							cout<<"Kembali ke menu cari ?(y/n)";cin>>jawabc;
						}
						break;
						case 3:
						{
							cetakqueue2();
							cout<<"Kembali ke menu cari ?(y/n)";cin>>jawabc;
						}
						break;
					
					}
				}while(jawabc=='y'||jawabc=='Y');
			}
		}
	
	}while(jawab=='y'||jawab=='Y');
}

void buatqueue()
{
	queue.belakang=0;
}

void buatqueue2()
{
	if(queuekosong())
	{
		queue2.belakang=0;
	}
}

int queuekosong()
{
	file = fopen("pasien.txt","r");
	fread(&queue.belakang,sizeof(queue.belakang),1,file);
	if(queue.belakang==0)
	return(true);
	else
	return(false);
}

int queuepenuh()
{
	file = fopen("pasien.txt","r");
	fread(&queue.belakang,sizeof(queue.belakang),1,file);
	if (queue.belakang==max)
	return(true);
	else
	return(false);
}

void enqueue()
{
	file = fopen("pasien.txt","w");
	if(queuepenuh())
	cout<<"queue overflow !\n";
	else
	{
		do
		{
				x++;		
				jumantri++;
				pasien[x].no++;
				cout<<"Input No.urut	:";cin>>pasien[x].no;
				cout<<"Input nama	:";cin>>pasien[x].nama;
				queue.belakang++;
				fwrite(&queue.belakang,sizeof(queue.belakang),1,file);
				fwrite(&pasien[x],sizeof(pasien[x]),1,file);
				
				cout<<"\nTambah lagi(y/n) ?";cin>>jawab1;
		}while(jawab1=='y'||jawab1=='Y');
	}
	fclose(file);
}

void enqueue2()
{
	file = fopen("pasien.txt","w");
	if(queuepenuh())
	cout<<"queue overflow !\n";
	else
	{	
			y++;
			jumpasien++;
			cout<<"==============INPUT DATA PASIEN==============\n";
			strcpy(pasien2[y].nama,pasien[y].nama);
			pasien2[y].no=pasien[y].no;
			cout<<"No Urut Pasien\t\t\t:"<<pasien2[y].no<<endl;
			cout<<"Nama Pasien\t\t\t:"<<pasien2[y].nama<<endl;
			cout<<"Input Tanggal Lahir(ddmmyy)	: ";cin>>pasien2[y].datap.tanggal;
			cout<<"Input Alamat			: ";cin.ignore();cin.getline(pasien2[y].datap.alamat,100);
			cout<<"Input Penyakit\t\t\t: ";cin.getline(pasien2[y].datap.penyakit,50);
			queue2.belakang++;
			fwrite(&queue2.belakang,sizeof(queue2.belakang),1,file);
			fwrite(&pasien2[y],sizeof(pasien2[y]),1,file);
	}
	fclose(file);
}

void dequeue()
{
	int i;
	if(queuekosong())
	cout<<"queue underflow !/n";
	else
	{
		jumantri--;
		for(i=1;i<queue.belakang;i++)
		pasien[i]=pasien[i+1];
		queue.belakang--;
		fwrite(&queue.belakang,sizeof(queue.belakang),1,file);
	}
}

void cetakqueue()
{
	file = fopen("pasien.txt","r");
	int i=1;
	//cout<<"Jumlah Antrian = "<<jumantri<<endl;
	fread(&queue.belakang,sizeof(queue.belakang),1,file);
	while(i<=queue.belakang)
	{
		fread(&pasien[i],sizeof(pasien[i]),1,file);
		cout<<"No. Antrian	= "<<pasien[i].no<<endl;
		cout<<"Nama		= "<<pasien[i].nama<<endl<<endl;
		i++;
	}
	fclose(file);
}

void cetakqueue2()
{
	file = fopen("pasien.txt","r");
	int i=1;
	//cout<<"Jumlah Pasien = "<<jumpasien<<endl;
	fread(&queue2.belakang,sizeof(queue2.belakang),1,file);
	while(i<=queue2.belakang)
	{
		fread(&pasien2[i],sizeof(pasien2[i]),1,file);
		cout<<"No. Antrian\t= "<<pasien2[i].no<<endl;
		cout<<"Nama		= "<<pasien2[i].nama<<endl;
		cout<<"Tanggal Lahir	= "<<pasien2[i].datap.tanggal<<endl;
		cout<<"Alamat\t\t= "<<pasien2[i].datap.alamat<<endl;
		cout<<"Penyakit	= "<<pasien2[i].datap.penyakit<<endl;
		i++;
	}
	fclose(file);
}

void carinama()
{
	int i=1;
	string namac;
	cout<<"Masukkan nama yang dicari(Spesifik) : ";cin>>namac;
	while(i<=queue.belakang)
	{
		if(namac==pasien[i].nama)
		{
			cout<<"No. Antrian	= "<<pasien[i].no<<endl;
			cout<<"Nama		= "<<pasien[i].nama<<endl;
		}
		i++;
	}
}


void carino()
{
	int i=1, noc;
	cout<<"Masukkan nomor yang dicari(Spesifik) : ";cin>>noc;
	while(i<=queue.belakang)
	{
		if(noc==pasien[i].no)
		{
			cout<<"No. Antrian	= "<<pasien[i].no<<endl;
			cout<<"Nama		= "<<pasien[i].nama<<endl;
		}
			i++;
	}
}
