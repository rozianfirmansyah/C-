#include <bits/stdc++.h>

using namespace std;

int main() {
	int total;
    double meal_cost,x=0,y=0;
    cin >> meal_cost;
    int tip_percent;
    cin >> tip_percent;
    int tax_percent;
    cin >> tax_percent;
    x=tip=meal_cost*tip_percent/100;
    y=tax=meal_cost*tax_percent/100;
    total=meal_cost+tip+tax;
    cout<<round(total)<<endl;
    return 0;
}
